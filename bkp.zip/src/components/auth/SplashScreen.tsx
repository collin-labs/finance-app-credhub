export function SplashScreen() {
  return (
    <div className="h-screen w-screen flex flex-col items-center justify-center bg-surface-950">
      <div className="flex flex-col items-center gap-4 animate-fade-in">
        <div className="w-16 h-16 rounded-2xl bg-brand-600 flex items-center justify-center">
          <span className="text-white text-2xl font-bold">C</span>
        </div>
        <h1 className="text-2xl font-bold text-white tracking-tight">CredHub</h1>
        <p className="text-surface-400 text-sm">Gestão de Crédito Consignado</p>
        <div className="mt-4 w-32 h-1 bg-surface-800 rounded-full overflow-hidden">
          <div className="h-full bg-brand-500 rounded-full animate-pulse" style={{ width: '60%' }} />
        </div>
      </div>
    </div>
  );
}
