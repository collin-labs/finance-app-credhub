import { invoke } from '@tauri-apps/api/core';

// Wrapper genérico que abstrai invoke do Tauri
// No futuro, quando implementar modo cliente (fetch HTTP), troca aqui
export async function api<T>(command: string, args?: Record<string, unknown>): Promise<T> {
  try {
    return await invoke<T>(command, args);
  } catch (error) {
    const msg = typeof error === 'string' ? error : (error as Error).message || 'Erro desconhecido';
    throw new Error(msg);
  }
}

// Auth
export const checkSetup = () => api<boolean>('check_setup');
export const setupAdmin = (input: { nome: string; login: string; senha: string; empresa_nome?: string }) =>
  api('setup_admin', { input });
export const login = (input: { login: string; senha: string }) =>
  api('login', { input });

// Gerenciamento de usuários (admin)
export const listarUsuarios = () => api('listar_usuarios');
export const criarUsuario = (input: unknown) => api<number>('criar_usuario', { input });
export const atualizarUsuario = (input: unknown) => api('atualizar_usuario', { input });
export const resetarSenhaUsuario = (usuarioId: number, novaSenha: string, adminId: number) =>
  api('resetar_senha_usuario', { usuario_id: usuarioId, nova_senha: novaSenha, admin_id: adminId });
export const alterarPropriaSenha = (usuarioId: number, senhaAtual: string, novaSenha: string) =>
  api('alterar_propria_senha', { usuario_id: usuarioId, senha_atual: senhaAtual, nova_senha: novaSenha });
export const recuperarSenhaAdmin = (login: string, recoveryCode: string, novaSenha: string) =>
  api('recuperar_senha_admin', { login, recovery_code: recoveryCode, nova_senha: novaSenha });
export const gerarNovoRecoveryCode = (usuarioId: number) =>
  api<string>('gerar_novo_recovery_code', { usuario_id: usuarioId });

// Clientes
export const listarClientes = (limite?: number, offset?: number) =>
  api('listar_clientes', { limite, offset });
export const buscarClientes = (termo: string) =>
  api('buscar_clientes', { termo });
export const obterCliente = (id: number) =>
  api('obter_cliente', { id });
export const criarCliente = (input: unknown) =>
  api<number>('criar_cliente', { input });
export const atualizarCliente = (id: number, input: unknown) =>
  api('atualizar_cliente', { id, input });
export const excluirCliente = (id: number, forcarDesativar: boolean) =>
  api<string>('excluir_cliente', { id, forcar_desativar: forcarDesativar });
export const verificarVinculosCliente = (id: number) =>
  api('verificar_vinculos_cliente', { id });

// Propostas
export const listarPropostas = (statusFiltro?: string, limite?: number) =>
  api('listar_propostas', { status_filtro: statusFiltro, limite });
export const obterProposta = (id: number) =>
  api('obter_proposta', { id });
export const criarProposta = (input: unknown) =>
  api<number>('criar_proposta', { input });
export const atualizarStatusProposta = (update: unknown) =>
  api('atualizar_status_proposta', { update });
export const obterHistoricoProposta = (propostaId: number) =>
  api('obter_historico_proposta', { proposta_id: propostaId });

// Bancos
export const listarBancos = () => api('listar_bancos');
export const criarBanco = (input: unknown) => api<number>('criar_banco', { input });
export const atualizarBanco = (id: number, input: unknown) => api('atualizar_banco', { id, input });

// Convenios
export const listarConvenios = () => api('listar_convenios');
export const criarConvenio = (input: unknown) => api<number>('criar_convenio', { input });
export const atualizarConvenio = (id: number, input: unknown) => api('atualizar_convenio', { id, input });

// Agentes
export const listarAgentes = () => api('listar_agentes');
export const criarAgente = (input: unknown) => api<number>('criar_agente', { input });
export const atualizarAgente = (id: number, input: unknown) => api('atualizar_agente', { id, input });
export const verificarVinculosAgente = (id: number) => api('verificar_vinculos_agente', { id });
export const excluirAgente = (id: number, forcarDesativar: boolean) => api<string>('excluir_agente', { id, forcar_desativar: forcarDesativar });

// Dashboard
export const obterStatsDashboard = () => api('obter_stats_dashboard');

// Comissões
export const listarComissoes = (filtroStatus?: string) =>
  api('listar_comissoes', { filtro_status: filtroStatus });
export const marcarComissaoRecebida = (comissaoId: number) =>
  api('marcar_comissao_recebida', { comissao_id: comissaoId });
export const marcarComissaoAgentePaga = (comissaoId: number) =>
  api('marcar_comissao_agente_paga', { comissao_id: comissaoId });
export const listarTabelasComissao = () => api('listar_tabelas_comissao');
export const criarTabelaComissao = (input: unknown) => api<number>('criar_tabela_comissao', { input });
export const excluirTabelaComissao = (id: number) => api('excluir_tabela_comissao', { id });

// Financeiro
export const listarLancamentos = (tipoFiltro?: string, statusFiltro?: string) =>
  api('listar_lancamentos', { tipo_filtro: tipoFiltro, status_filtro: statusFiltro });
export const criarLancamento = (input: unknown) => api<number>('criar_lancamento', { input });
export const marcarLancamentoPago = (id: number) => api('marcar_lancamento_pago', { id });
export const obterResumoFinanceiro = () => api('obter_resumo_financeiro');

// Backup
export const fazerBackup = (destino: string) => api('fazer_backup', { destino });
export const fazerBackupAutomatico = (manter?: number) => api('fazer_backup_automatico', { manter });
export const listarBackupsAutomaticos = () => api('listar_backups_automaticos');
export const validarBackup = (caminho: string) => api('validar_backup', { caminho });
export const restaurarBackup = (caminho: string) => api<string>('restaurar_backup', { caminho });

// Empresa (identidade)
export const obterIdentidadeEmpresa = () => api('obter_identidade_empresa');
export const salvarIdentidadeEmpresa = (identidade: unknown) => api('salvar_identidade_empresa', { identidade });

// Prospecção — Campanhas
export const listarCampanhas = () => api('listar_campanhas');
export const criarCampanha = (input: unknown) => api<number>('criar_campanha', { input });
export const atualizarStatusCampanha = (id: number, status: string) => api('atualizar_status_campanha', { id, status });

// Prospecção — Leads
export const listarLeads = (campanhaId?: number, statusFiltro?: string, agenteId?: number) =>
  api('listar_leads', { campanha_id: campanhaId, status_filtro: statusFiltro, agente_id: agenteId });
export const criarLead = (input: unknown) => api<number>('criar_lead', { input });
export const importarLeads = (campanhaId: number | undefined, linhas: unknown[]) =>
  api('importar_leads', { campanha_id: campanhaId, linhas });
export const atualizarStatusLead = (update: unknown) => api('atualizar_status_lead', { update });
export const distribuirLeads = (leadIds: number[], agenteId: number) =>
  api('distribuir_leads', { lead_ids: leadIds, agente_id: agenteId });
export const listarInteracoesLead = (leadId: number) => api('listar_interacoes_lead', { lead_id: leadId });
export const criarInteracaoLead = (input: unknown) => api<number>('criar_interacao_lead', { input });
export const converterLeadEmCliente = (leadId: number) => api<number>('converter_lead_em_cliente', { lead_id: leadId });
export const excluirLead = (id: number) => api('excluir_lead', { id });
